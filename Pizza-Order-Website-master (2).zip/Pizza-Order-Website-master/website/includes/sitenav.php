<div id="sitenav">
  <!--Site Nav Wrapper Opens-->
  <div class="wrapper">
    <ul>
      <li><a href="http://foodservices.appstate.edu/dining" class="none">Dining</a></li>
	  <li><a href="http://foodservices.appstate.edu/catering-special-events">Catering & Special Events</a></li>
	  <li><a href="http://foodservices.appstate.edu/news-events">News & Events</a></li>
	  <li><a href="http://foodservices.appstate.edu/sustainability">Sustainability & Local Food</a></li>
	  <li><a href="http://foodservices.appstate.edu/about-0">About</a></li>
          <li><a href="http://foodservices.appstate.edu/contact">Contact</a></li>
    </ul>
    <!--Site Nav Wrapper Closes-->
  </div>
  <!--Site Nav Closes-->
</div>
<!--Content Wrapper Opens-->
<div class="wrapper">

  <!--Yellow Bar Opens-->
  <div id="siteinfo">
    <!-- TemplateBeginIf cond="breadcrumbs" --><!-- TemplateBeginEditable name="EditRegion6" --><div id="crumbs">
      <p></p>
    </div><!-- TemplateEndEditable --><!-- TemplateEndIf -->
    <div id="sectnav">
      <p>Section Navigation</p>
    </div>
  </div>
