<!-- Footer-->
<div id="footer">
  <p id="footnav"> <a href="http://www.appstate.edu">Appalachian State University</a> - <a href="http://cs.appstate.edu/">Department of Computer Science</a> - <a href="mailto:hobsonws@appstate.edu">Webmaster</a> - <a href="http://www.web.appstate.edu/disclaimer.html">Disclaimer</a> - <a href="http://www.edc.appstate.edu/equity/EOpolicy.html" title="View Appalachian State University's Equal Opportunity Policy">EO Policy</a> - <a href="http://transcoder.usablenet.com/tt/referrer" title="View page as text-only" rel="nofollow">Text Only</a></p>
  <address>
    <a href="http://www.appstate.edu/"><img src="images/foot_logo.gif" alt="Appalachian State University Logo" width="116" height="33" class="logo" /></a>&copy; <?php echo date("Y"); ?> Appalachian State University Boone, NC 28608 / 828-262-2000
  </address>
  <!-- End of Footer-->
</div>
<!-- End Wrapper-->
</div>
<!-- End Page Content-->
<script src="js/custom.js" type="text/javascript"></script>
</body>
</html>