<?php

$server = "";
$user = "";
$pass = "";
$db = "";

$conn = mysqli_connect($server, $user, $pass, $db) or die("Unable to establish connection to server. Did you set connection values in connect.php?");

?>
